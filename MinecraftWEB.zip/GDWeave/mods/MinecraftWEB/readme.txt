Thanks for playing with MinecraftWEB!

Over 15 new Minecraft-themed items to collect in this content mod for WEBFISHING!

Version: 1.0.0
Authors: MonkeyMan1242
https://github.com/MonkeyMan1242/MinecraftWEB

This mod was made with Hatchery 1.2.0
https://github.com/coolbot100s/Hatchery